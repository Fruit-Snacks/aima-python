import deepdsp

deepdsp.main()