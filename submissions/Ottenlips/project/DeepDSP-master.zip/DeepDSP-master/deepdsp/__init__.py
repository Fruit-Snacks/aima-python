from deepdsp.classify.classifyHighway import classifyHighway
from deepdsp.classify.classifyConv2d import classifyConv2d


def main():
    classifyConv2d()
    # classifyHighway()
